package wrapper;

public class WrapperUtilMain {
	public static void main(String[] args) {
		Integer integer1 = Integer.valueOf(10);
		Integer integer2 = Integer.valueOf("10");
		
		int intValue = Integer.parseInt("10");
		
		
		
		
	}
}
