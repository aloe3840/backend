package wrapper;

public class SystemMain {
	public static void main(String[] args) {
		//현재 시간 가져오기
		long currentTimeMillis = System.currentTimeMillis();
		System.out.println(currentTimeMillis);
		
		
	}
}
