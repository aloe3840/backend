package exception;

public class MyCheckedException extends Exception{
	public MyCheckedException(String massage) {
		super(massage);
	}
}
