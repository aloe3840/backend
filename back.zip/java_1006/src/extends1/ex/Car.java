package extends1.ex;

public class Car {
	public void move() {
		System.out.println("차를 이동합니다");
	}
}
