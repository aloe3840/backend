package extends1.ex;

public class GasCar extends Car{
	
	public void charge() {
		System.out.println("차를 주유");
	}
}
