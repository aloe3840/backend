package extends1.ex;

public class ElectricCar extends Car{

	public void charge() {
		System.out.println("차 주유");
	}
}
